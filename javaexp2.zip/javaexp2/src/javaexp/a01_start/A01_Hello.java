package javaexp.a01_start;

public class A01_Hello {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// 한줄 주석 : 실행에 영향 없음. 주로 코드에 대한 설명
		// 명시적으로 타이핑으로도 처리가 된다.
		// ctrl + (+/-) : 화면 글자 크기조절
		// ctrl + / : 주석 처리 단축키
		/*
		 * 여러 줄 주석 단축키(실행에 영향 없음)
		 */
		System.out.println("자바 드디어 실행!");
		// 출력을 위한 명령문
		// sysout(타이핑) + ctrl + space 키로도 생성
		System.out.println("자동 키로 출력 생성");
		// ctrl + m (전체화면 / 부분메뉴화면)
		
		// 오른쪽 마우스 run as + java application
		// ctrl + f11 : 실행 단축키
		
		// ex1) 안녕하세요 라는 문자열이 출력되게 하고.
		// ex2) A02_Hello.java로 만들어서
		//      두번째 자바실행 이라고 출력되게 하세요.
		System.out.println("안녕하세요");
	}

}
