package javaexp.a01_start;

import java.util.*; // 외부 객체를 사용할 때 선언

public class A05_Scanner {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//System.out.println("이름을 입력하세요");
		// 내장된 객체로 문자열 데이터 입력
		//Scanner sc = new Scanner(System.in);
		// 입력한 데이터를 String으로 하는 name에 할당해서 하단에 출력한다.
		//String name = sc.nextLine();
		//System.out.print("입력한 이름은");
		//System.out.println(name);
		// ex) 좋아하는 과일명을 입력 후 출력하세요
		//	String fruit 로 문자열에 할당 처리
		System.out.print("좋아하는 과일을 입력하세요 : ");
		Scanner sc = new Scanner(System.in);
		String fruit = sc.nextLine();
		System.out.print("입력한 과일은 ");
		System.out.println(fruit);
	}

}
