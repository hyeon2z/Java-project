package javaexp.a06_objectreview;

public class A06_ObjVsObjexp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		1. 사람과 여권
		    한 사람은 하나의 여권만 소유할 수 있고, 
		    여권은 한 사람에게만 발급된다
		    ```java
		    class Person {
		        Passport passport;
		    }
		    class Passport {
		        Person person;
		    }
		    
		2. 방과 전구
		    한 방에는 하나의 전구만 설치된다.
		    ```java
		    class Room {
		        Bulb bulb;
		    }
		    class Bulb {
		        Room room;
		 */
	}

}
