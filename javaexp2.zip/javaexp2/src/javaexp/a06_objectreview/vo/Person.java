// 제일 상단 - 이 클래스가 소속되어있는 묶음 위치 (패키지)
package javaexp.a06_objectreview.vo;

// 접근제어자+class+대문자로 시작하는 클래스 명 {}
public class Person {

}
