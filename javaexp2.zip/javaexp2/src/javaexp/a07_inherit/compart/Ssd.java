package javaexp.a07_inherit.compart;

public class Ssd extends Part {
	void partUse() {
		mainPrint();
		System.out.println("정보를 저장하는 기능");
	}
	void execute() {
		System.out.println("정보를 저장");
	}
}
