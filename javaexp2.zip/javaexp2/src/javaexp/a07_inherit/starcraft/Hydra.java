package javaexp.a07_inherit.starcraft;

public class Hydra extends Larba {
	public void attack() {
		System.out.println("히드라가 공격합니다");
	}
}
