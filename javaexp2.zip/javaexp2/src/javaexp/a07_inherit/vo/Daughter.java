package javaexp.a07_inherit.vo;

public class Daughter extends Mother {
public int height;
	
	public Daughter() {}
	
	public void goShpping() {
		
	}
	public void hobbyList() {
		System.out.println(hobby);
	}
}
