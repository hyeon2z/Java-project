package javaexp.a07_inherit.vo;

public class Player {
	// 상위에서 선언하고 하위에서는 모두다 공통으로 활용가능
	public Player() {}
	
	public void running() {
		System.out.println("달린다!");
	}

}
