package javaexp.mini_program;

import javaexp.mini_program.vo2.Hero;
import javaexp.mini_program.vo2.Slime;

public class a02_program_rpg {

	public static void main(String[] args) {
		Hero hero = new Hero();
		Slime slime = new Slime();
		hero.heroInfo();
		
		
		
	}

}
