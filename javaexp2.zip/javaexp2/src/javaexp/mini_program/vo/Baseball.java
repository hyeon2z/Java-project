package javaexp.mini_program.vo;

public class Baseball {
	String player; // 플레이어 이름
	
	public Baseball(String player) {
		this.player = player;
		
	}
	
	public String getPlayer() {
		return player;
	}
	
}
