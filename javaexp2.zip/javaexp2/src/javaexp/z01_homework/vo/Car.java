package javaexp.z01_homework.vo;

public class Car {
	String num;
	String model;
	int year;
	
	public Car(String num, String model) {
		this.num = num;
		this.model = model;
	}
	
	public void carInfo() {
		System.out.println("#차량의 정보#");
		System.out.println("차량 번호 : " + num);
		System.out.println("차량 모델 : " + model);
		System.out.println("차량 연식 : " + getYear());
	}
	
	public void setYear(int year) {
		System.out.println("연식 변경 : " + year + "\n");
		this.year = year;
	}
	
	public int getYear() {
		return year;
	}
}
