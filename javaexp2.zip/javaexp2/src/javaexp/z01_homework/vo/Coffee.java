package javaexp.z01_homework.vo;

public class Coffee {
	String type;
	int price;
	String from;
	
	public Coffee(String type) {
		this.type = type;
		
	}
	
	public void cofInfo() {
		System.out.println("#커피의 정보#");
		System.out.println("종류 : " + type);
		System.out.println("커피의 가격 : " + price);
		System.out.println("커피의 원산지 : " + from);
	}
	
	public int getPrice() {
		return price;
	}
	// 커피 가격변경
	public void setPrice(int price) {
		System.out.println("커피 가격 변경 : " + price + "\n");
		this.price = price;
	}

	public String getFrom() {
		return from;
	}
	// 원산지 변경
	public void setFrom(String from) {
		System.out.println("커피 원산지 입력 : " + from + "\n");
		this.from = from;
	}
	
	
}
