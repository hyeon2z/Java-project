package javaexp.z01_homework.vo;

public class Game {
	String name;
	int level;
	int hp;
	
	public Game(String name, int level, int hp) {
		this.name = name;
		this.level = level;
		this.hp = hp;
	}

	public void gameInfo() {
		System.out.println("#게임 정보#");
		System.out.println("캐릭터 이름 : " + name);
		System.out.println("레벨 : " + level);
		System.out.println("체력 : " + hp);
		
	}
	
	public int getLevel() {
		level++;
		System.out.println("레벨 업!!");
		return level;
	}

	public void setHp(int hp) {
		System.out.println(hp + "만큼 체력을 회복합니다." + "\n");
		this.hp = hp;
	}
	
}
