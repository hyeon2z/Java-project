package javaexp.z01_homework.vo;

public class Travle {
	String locate;
	int start;
	int arrive;
	
	public Travle(String locate, int start, int arrive) {
		this.locate = locate;
		this.start = start;
		this.arrive = arrive;
	}
	public void traInfo() {
		System.out.println("#여행정보#");
		System.out.println("목적지 : " + locate);
		System.out.println("출발일 : " + start);
		System.out.println("도착일 : " + arrive);
		calcul();
	}
	
	public void calcul() {
		int cnt = arrive - start;
		
		System.out.println("여행 일수 : " + cnt + "일");
	}
}
