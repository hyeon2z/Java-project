package javaexp.z02_homework;

public class A0926 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		# 아래 내용을 java 문제로  개념 정리하고 내용 확인해주세요
//
//		[개념] 1. 배열의 선언과 할당 기본형식의 종류를 예제를 통해 기술하세요
		// 배열의 선언
//		int [] Arry; // stack 영역에 배열선언
//		int [] Arry = new int[5]; // 배열의 선언과 동시에 heap 영역 데이터 공간 할당
//		int [] Arry = {1, 5, 16}; // 배열의 선언과 동시에 데이터 공간할당 및 데이터 입력까지 한번에 하는법
		
//		[개념] 2. 배열의 기본 속성들을 기술하세요.
		// 배열의 길이 - 배열.length()
		// 값을 할당하지 않으면 숫자형은 0, 문자열은 null로 초기화 된다.
		// []을 늘려서 2차원 , 3차원 배열을 만들수 있다.
		
//		[확인] 3. Math.random()으로 주사위 5회 던진 결과를 배열에 할당 처리하고 출력하세요.
//		int [] dice = new int[5];
//		
//		for(int i = 0; i < 5; i ++) {
//			dice[i] = (int)(Math.random() * 6 + 1);
//			System.out.println(i+1 + "번째 주사위의 결과 : " + dice[i]);
//		}
		
//		[개념] 4. 배열과 반복문의 관계를 각 속성과 예제를 통해서 설명하세요
//		
//		int [] Arry = new int[3];
//		for 반복문에 배열의 길이를 이용해서 반복문의 한계치를 정하거나
//		for(int i = 0; i < Arry.length; i ++) {
//			
//		}
		
//		int i = 0;
//		while 문에서 반복조건 등을 설정할 수 있다.
//		while(Arry[i] != Arry[2]) {
//			System.out.println(i);
//			i++;
//		}
		
//		배열의 index는 반복문에서 사용 할 변수가 된다.
		
		
//		forEach구문은 배열안에 있는 요소들을 처음부터 하나씩 가져와서 단위데이터에 할당하는데,
//		배열안에 있는 요소들을 처음부터 끝까지 할당하게 해준다.
		
		
		
//		[확인] 5. 학생 30명의 점수를 배열로 초기로 일단, 선언하고, for문을 통해서 임의의 점수(0~100)까지 할당해 보세요.
//		int [] stupt = new int[30];
//		
//		for(int i = 0; i < stupt.length; i ++) {
//			stupt[i] = (int)(Math.random() * 101);
//		}
		
		
//		[토론] 6. for문과 배열과의 관계에서 기본형식과 foreach문의 장단점과 사용하는 각각 적절한 활용 시점 토의해 보자.

	}

}
