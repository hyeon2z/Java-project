package javaexp.z02_homework.package1;

public class Melon {
	private void melon1() {
		System.out.println("private 참외");
	}
	protected void melon2() {
		System.out.println("protected 참외");
	}
	void melon3() {
		System.out.println("default 참외");
	}
	public void melon4() {
		System.out.println("public 참외");
	}
}
