package javaexp.z02_homework.package3;

import javaexp.z02_homework.package1.Melon;

public class WaterMelon extends Melon {
	public void melonCall() {
		
//		melon1(); 
		melon2(); // 타 패키지지만 상속받았으므로 protected 가능
//		melon3(); 
		melon4(); // public 가능
	}
	
}
