package javaexp.a01_start;

public class A02_Hello {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("두번째 자바 실행");
		// ctrl + shift + f : 소스정리 단축키
		System.out.println("안녕");
		System.out.println("두번째 안녕");
		
	}

}
