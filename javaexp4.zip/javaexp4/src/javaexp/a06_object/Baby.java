package javaexp.a06_object;

public class Baby {

}
