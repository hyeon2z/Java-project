package javaexp.a06_object;

public class Book {
	public String title;
	int Price;

}
