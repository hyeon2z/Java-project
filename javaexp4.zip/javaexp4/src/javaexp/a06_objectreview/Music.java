package javaexp.a06_objectreview;

class Music {

}
