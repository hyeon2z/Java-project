package javaexp.a06_objectreview.vo;

public class Food {
	// 생성자는 overloading 규칙에 의해
	// 여러개 선언이 가능하고, 생성될 때 호출이 된다.
	
	public Food() {}
	Food(String name){}
	
}
