package javaexp.a06_objectreview.vo2;

public class Passport {
	private Person person;
	private String isbn;
	private String nation;

}
