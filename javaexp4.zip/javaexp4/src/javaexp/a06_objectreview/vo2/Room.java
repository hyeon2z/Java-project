package javaexp.a06_objectreview.vo2;

public class Room {

}
