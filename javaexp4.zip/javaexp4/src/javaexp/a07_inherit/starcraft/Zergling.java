package javaexp.a07_inherit.starcraft;

public class Zergling extends Larba {
	public void attack() {
		System.out.println("저글링이 공격합니다");
	}
}
