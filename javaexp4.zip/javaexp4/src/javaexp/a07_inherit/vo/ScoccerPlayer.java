package javaexp.a07_inherit.vo;

public class ScoccerPlayer extends Player {
	public ScoccerPlayer() {}
	
	public void drivingBall() {
		System.out.println("공을 몰다");
	}
}
