package javaexp.a08_access.fruit;

public class Apple {
	private String apple = "사과";
	public void callTaste() {
		Melon m1 = new Melon();
		m1.taste();
	}
}
