package javaexp.mini_program.vo2;

public class Inventory {

}
