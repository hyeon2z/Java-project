package javaexp.y01_util;

public class A02_ErrorTracking {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int no = 0;
		System.out.println(++no + "번째 라인 코드");
		System.out.println(++no + "번째 라인 코드");
		System.out.println(++no + "번째 라인 코드");
		System.out.println(++no + "번째 라인 코드");
		System.out.println(++no + "번째 라인 코드");
		System.out.println(++no + "번째 라인 코드");
		System.out.println(++no + "번째 라인 코드");
		System.out.println(++no + "번째 라인 코드");
		System.out.println(++no + "번째 라인 코드");
		System.out.println(++no + "번째 라인 코드");
		System.out.println(++no + "번째 라인 코드");
		System.out.println(++no + "번째 라인 코드");
		System.out.println(++no + "번째 라인 코드");
		System.out.println(++no + "번째 라인 코드");
		double a = (double)5/2;
		System.out.println(a);
		a+=1;
		System.out.println(a);
		
	}	// F11 -> debug tracking F8 -> 실행
		// 왼쪽 breakpoint 설정
	
		
		

}
