package javaexp.z02_homework.package1;

public class Strawberry {
	Melon ml = new Melon();
	public void melonCall() {
		Melon ml = new Melon();
//		ml.melon1(); 
		ml.melon2();
		ml.melon3(); 
		ml.melon4(); // public만 가능
	}
}
