package javaexp.z02_homework.package2;

import javaexp.z02_homework.package1.Melon;

public class Carrot {
	
	public void melonCall() {
		Melon ml = new Melon();
//		ml.melon1(); 
//		ml.melon2();
//		ml.melon3(); 
		ml.melon4(); // public만 가능
	}
}
